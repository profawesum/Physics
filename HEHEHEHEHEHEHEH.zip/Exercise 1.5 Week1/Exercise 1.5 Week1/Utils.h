#pragma once

#include <glm.hpp>

using namespace glm;

struct Vec3 {
	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;

	Vec3(void) {

	}

	Vec3(const float x, const float y, const float z) {
		this->x = x;
		this->y = y;
		this->z = z;
	}

	Vec3 operator - (Vec3 B) {
		return Vec3{ x - B.x, y - B.y, z - B.z };
	};

	Vec3 operator + (Vec3 B) {
		return Vec3{ x + B.x, y + B.y, z + B.z };
	};

	Vec3 operator / (Vec3 B) {
		return Vec3{ x / B.x, y / B.y, z / B.z };
	};

	Vec3 operator * (float B) {
		return Vec3{ x * B, y * B, z * B };
	}

	bool operator != (Vec3 B) {
		if (x != B.x || y != B.y || z != B.z) {
			return true;
		}
		return false;
	}

	bool operator == (Vec3 B) {
		if (x != B.x || y != B.y || z != B.z) {
			return false;
		}
		return true;
	}

};

struct Vec2 {
	float x = 0.0f;
	float y = 0.0f;
};

struct TriPoints {
	Vec3 firstPoint = { -9999, -9999, 0 };
	Vec3 secondPoint = { -9999, -9999, 0 };
	Vec3 thirdPoint = { -9999, -9999, 0 };
};

struct LineData {
	Vec3 firstPoint = { -9999, -9999, 0 };
	Vec3 secondPoint = { -9999, -9999, 0 };
};
