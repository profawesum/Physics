#pragma once
#include <glew.h>
#include <freeglut.h>
#include <vector>
#include <SOIL.h>
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>

#include "Utils.h"

using namespace std;

class GameObject {

public:

	enum objectType {
		UNDEFINIED,
		TRIANGLE,
		LINE
	};
	GameObject(LineData positions); //line
	GameObject(TriPoints positions); //triangle
	~GameObject();
	objectType type;

	void Render();

	LineData getLineData();
	TriPoints getTrianglePoint();
	LineData lineData;
	TriPoints triPoints;
	bool killMe = false;

private:


	Vec3 color = { 0,0,0 };

};

class Scene {
public:
	vector<GameObject*> GameObjects;
	bool drawingTriangle = true;

};

void CutATriangle(GameObject* triangle, GameObject* line);
